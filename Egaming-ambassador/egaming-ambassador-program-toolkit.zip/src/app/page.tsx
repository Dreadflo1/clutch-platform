import AmbassadorDashboard from "@/components/ambassador-dashboard";

export default function HomePage() {
  return <AmbassadorDashboard />;
}
